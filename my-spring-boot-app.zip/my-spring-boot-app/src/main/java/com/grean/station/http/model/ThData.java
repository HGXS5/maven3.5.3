//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.http.model;

import com.grean.station.http.utils.JsonUtil;
import java.time.LocalDateTime;

public class ThData {
    public String placeId;
    public String equipId;
    public Integer equipType;
    public Boolean resend;
    public LocalDateTime sampletime;
    public Double c1;
    public Double c2;
    public Double c3;
    public Double c4;
    public Double c5;
    public Double c6;
    public Double c7;
    public Double c8;
    public Double c9;
    public Double c10;
    public Double c11;
    public Double c12;
    public Double c13;
    public Double c14;
    public Double c15;
    public Double c16;
    public Double c17;
    public Double c18;
    public Double c19;
    public Double c20;
    public Double c21;
    public Double c22;
    public Double c23;
    public Double c24;
    public Double c25;
    public Double c26;
    public Double c27;
    public Double c28;
    public Double c29;
    public Double c30;

    public ThData() {
    }

    public String toString() {
        return JsonUtil.toJson(this);
    }
}
