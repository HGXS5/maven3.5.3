//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.service.dev.sample;

public interface SampleExeListener {
  void OnExeEvent(String var1, int var2, int var3, String var4, String var5);
}
