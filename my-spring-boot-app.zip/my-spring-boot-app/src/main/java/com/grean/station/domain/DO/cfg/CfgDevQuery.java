//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgDevQuery {
  int id;
  int devid;
  int factorid;
  String protoType;
  int queryType;
  String queryCmd;
  String dataType;
  String dataFormat;
  int dataIndex;
  int dataLength;
  double updateA;
  double updateB;

  public CfgDevQuery() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDevid() {
    return this.devid;
  }

  public void setDevid(int devid) {
    this.devid = devid;
  }

  public int getFactorid() {
    return this.factorid;
  }

  public void setFactorid(int factorid) {
    this.factorid = factorid;
  }

  public String getProtoType() {
    return this.protoType;
  }

  public void setProtoType(String protoType) {
    this.protoType = protoType;
  }

  public int getQueryType() {
    return this.queryType;
  }

  public void setQueryType(int queryType) {
    this.queryType = queryType;
  }

  public String getQueryCmd() {
    return this.queryCmd;
  }

  public void setQueryCmd(String queryCmd) {
    this.queryCmd = queryCmd;
  }

  public String getDataType() {
    return this.dataType;
  }

  public void setDataType(String dataType) {
    this.dataType = dataType;
  }

  public int getDataIndex() {
    return this.dataIndex;
  }

  public void setDataIndex(int dataIndex) {
    this.dataIndex = dataIndex;
  }

  public int getDataLength() {
    return this.dataLength;
  }

  public void setDataLength(int dataLength) {
    this.dataLength = dataLength;
  }

  public String getDataFormat() {
    return this.dataFormat;
  }

  public void setDataFormat(String dataFormat) {
    this.dataFormat = dataFormat;
  }

  public double getUpdateA() {
    return this.updateA;
  }

  public void setUpdateA(double updateA) {
    this.updateA = updateA;
  }

  public double getUpdateB() {
    return this.updateB;
  }

  public void setUpdateB(double updateB) {
    this.updateB = updateB;
  }
}
