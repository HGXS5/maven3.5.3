//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.service.script;

import com.grean.station.domain.request.RtdCount;

public interface ScriptCountListener {
  void OnCountEvent(RtdCount var1);
}
