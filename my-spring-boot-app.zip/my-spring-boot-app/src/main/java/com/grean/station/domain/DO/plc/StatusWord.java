//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.plc;

public class StatusWord {
  private int id;
  private String name;
  private String pic1;
  private String pic2;

  public StatusWord() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPic1() {
    return this.pic1;
  }

  public void setPic1(String pic1) {
    this.pic1 = pic1;
  }

  public String getPic2() {
    return this.pic2;
  }

  public void setPic2(String pic2) {
    this.pic2 = pic2;
  }
}
