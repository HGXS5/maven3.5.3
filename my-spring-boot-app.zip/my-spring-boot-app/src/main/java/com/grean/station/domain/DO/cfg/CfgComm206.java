//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgComm206 {
  int id;
  String name;
  String unit;
  int tlen;
  int plen;

  public CfgComm206() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getUnit() {
    return this.unit;
  }

  public void setUnit(String unit) {
    this.unit = unit;
  }

  public int getTlen() {
    return this.tlen;
  }

  public void setTlen(int tlen) {
    this.tlen = tlen;
  }

  public int getPlen() {
    return this.plen;
  }

  public void setPlen(int plen) {
    this.plen = plen;
  }
}
