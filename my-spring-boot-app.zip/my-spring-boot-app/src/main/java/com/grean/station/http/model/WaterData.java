//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.http.model;

import java.util.List;

public class WaterData {
    String datatime;
    List<Double> list;

    public WaterData() {
    }

    public String getDatatime() {
        return this.datatime;
    }

    public void setDatatime(String datatime) {
        this.datatime = datatime;
    }

    public List<Double> getList() {
        return this.list;
    }

    public void setList(List<Double> list) {
        this.list = list;
    }
}
