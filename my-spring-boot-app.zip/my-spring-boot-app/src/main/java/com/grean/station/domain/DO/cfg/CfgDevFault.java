//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgDevFault {
  int id;
  int dev_id;
  int fault_id;
  String fault_type;
  String fault_desc;

  public CfgDevFault() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDev_id() {
    return this.dev_id;
  }

  public void setDev_id(int dev_id) {
    this.dev_id = dev_id;
  }

  public int getFault_id() {
    return this.fault_id;
  }

  public void setFault_id(int fault_id) {
    this.fault_id = fault_id;
  }

  public String getFault_type() {
    return this.fault_type;
  }

  public void setFault_type(String fault_type) {
    this.fault_type = fault_type;
  }

  public String getFault_desc() {
    return this.fault_desc;
  }

  public void setFault_desc(String fault_desc) {
    this.fault_desc = fault_desc;
  }
}
