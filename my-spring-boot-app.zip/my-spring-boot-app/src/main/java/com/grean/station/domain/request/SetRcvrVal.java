//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class SetRcvrVal {
    int key;
    String factor;
    Double motherVal;
    Double motherVol;
    Double concVal;
    Double cupVol;
    Double rateMin;
    Double rateMax;
    String rcvrType;
    Double multiple = 1.0D;
    Double rcvrLimit;

    public SetRcvrVal() {
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getFactor() {
        return this.factor;
    }

    public void setFactor(String factor) {
        this.factor = factor;
    }

    public Double getMotherVal() {
        return this.motherVal;
    }

    public void setMotherVal(Double motherVal) {
        this.motherVal = motherVal;
    }

    public Double getMotherVol() {
        return this.motherVol;
    }

    public void setMotherVol(Double motherVol) {
        this.motherVol = motherVol;
    }

    public Double getCupVol() {
        return this.cupVol;
    }

    public void setCupVol(Double cupVol) {
        this.cupVol = cupVol;
    }

    public Double getConcVal() {
        return this.concVal;
    }

    public void setConcVal(Double concVal) {
        this.concVal = concVal;
    }

    public Double getRateMin() {
        return this.rateMin;
    }

    public void setRateMin(Double rateMin) {
        this.rateMin = rateMin;
    }

    public Double getRateMax() {
        return this.rateMax;
    }

    public void setRateMax(Double rateMax) {
        this.rateMax = rateMax;
    }

    public String getRcvrType() {
        return this.rcvrType;
    }

    public void setRcvrType(String rcvrType) {
        this.rcvrType = rcvrType;
    }

    public Double getMultiple() {
        return this.multiple;
    }

    public void setMultiple(Double multiple) {
        this.multiple = multiple;
    }

    public Double getRcvrLimit() {
        return this.rcvrLimit;
    }

    public void setRcvrLimit(Double rcvrLimit) {
        this.rcvrLimit = rcvrLimit;
    }
}
