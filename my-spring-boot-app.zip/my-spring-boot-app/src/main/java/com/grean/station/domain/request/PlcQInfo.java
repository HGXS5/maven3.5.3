//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class PlcQInfo {
  int key;
  private String name;
  private String pname;
  private int address;
  private String defvalue;

  public PlcQInfo() {
  }

  public int getKey() {
    return this.key;
  }

  public void setKey(int key) {
    this.key = key;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPname() {
    return this.pname;
  }

  public void setPname(String pname) {
    this.pname = pname;
  }

  public int getAddress() {
    return this.address;
  }

  public void setAddress(int address) {
    this.address = address;
  }

  public String getDefvalue() {
    return this.defvalue;
  }

  public void setDefvalue(String defvalue) {
    this.defvalue = defvalue;
  }
}
