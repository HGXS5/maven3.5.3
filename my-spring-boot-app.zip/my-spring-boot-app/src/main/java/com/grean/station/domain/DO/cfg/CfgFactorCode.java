//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgFactorCode {
  int id;
  String name;
  String code;
  int decimals;
  String unit;
  double unitParam = 1.0D;

  public CfgFactorCode() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCode() {
    return this.code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public int getDecimals() {
    return this.decimals;
  }

  public void setDecimals(int decimals) {
    this.decimals = decimals;
  }

  public String getUnit() {
    return this.unit;
  }

  public void setUnit(String unit) {
    this.unit = unit;
  }

  public double getUnitParam() {
    return this.unitParam;
  }

  public void setUnitParam(double unitParam) {
    this.unitParam = unitParam;
  }
}
