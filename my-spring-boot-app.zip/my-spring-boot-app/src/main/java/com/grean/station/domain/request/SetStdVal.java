//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class SetStdVal {
    int key;
    String factor;
    Double stdZero;
    Double stdSpan;
    Double stdStd;
    Double stdBlnk;

    public SetStdVal() {
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getFactor() {
        return this.factor;
    }

    public void setFactor(String factor) {
        this.factor = factor;
    }

    public Double getStdZero() {
        return this.stdZero;
    }

    public void setStdZero(Double stdZero) {
        this.stdZero = stdZero;
    }

    public Double getStdSpan() {
        return this.stdSpan;
    }

    public void setStdSpan(Double stdSpan) {
        this.stdSpan = stdSpan;
    }

    public Double getStdStd() {
        return this.stdStd;
    }

    public void setStdStd(Double stdStd) {
        this.stdStd = stdStd;
    }

    public Double getStdBlnk() {
        return this.stdBlnk;
    }

    public void setStdBlnk(Double stdBlnk) {
        this.stdBlnk = stdBlnk;
    }
}
