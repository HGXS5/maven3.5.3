//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.rec;

import java.sql.Timestamp;

public class RecDataTime {
  private int id;
  private Timestamp recTime;
  private Timestamp sendTime1;
  private Timestamp sendTime2;
  private Timestamp sendTime3;
  private Timestamp sendTime4;
  private Timestamp sendTime5;
  private Timestamp sendTime6;
  private Timestamp sendTime7;
  private Timestamp sendTime8;
  private Timestamp sendTime9;
  private Timestamp sendTime10;

  public RecDataTime() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public Timestamp getRecTime() {
    return this.recTime;
  }

  public void setRecTime(Timestamp recTime) {
    this.recTime = recTime;
  }

  public Timestamp getSendTime1() {
    return this.sendTime1;
  }

  public void setSendTime1(Timestamp sendTime1) {
    this.sendTime1 = sendTime1;
  }

  public Timestamp getSendTime2() {
    return this.sendTime2;
  }

  public void setSendTime2(Timestamp sendTime2) {
    this.sendTime2 = sendTime2;
  }

  public Timestamp getSendTime3() {
    return this.sendTime3;
  }

  public void setSendTime3(Timestamp sendTime3) {
    this.sendTime3 = sendTime3;
  }

  public Timestamp getSendTime4() {
    return this.sendTime4;
  }

  public void setSendTime4(Timestamp sendTime4) {
    this.sendTime4 = sendTime4;
  }

  public Timestamp getSendTime5() {
    return this.sendTime5;
  }

  public void setSendTime5(Timestamp sendTime5) {
    this.sendTime5 = sendTime5;
  }

  public Timestamp getSendTime6() {
    return this.sendTime6;
  }

  public void setSendTime6(Timestamp sendTime6) {
    this.sendTime6 = sendTime6;
  }

  public Timestamp getSendTime7() {
    return this.sendTime7;
  }

  public void setSendTime7(Timestamp sendTime7) {
    this.sendTime7 = sendTime7;
  }

  public Timestamp getSendTime8() {
    return this.sendTime8;
  }

  public void setSendTime8(Timestamp sendTime8) {
    this.sendTime8 = sendTime8;
  }

  public Timestamp getSendTime9() {
    return this.sendTime9;
  }

  public void setSendTime9(Timestamp sendTime9) {
    this.sendTime9 = sendTime9;
  }

  public Timestamp getSendTime10() {
    return this.sendTime10;
  }

  public void setSendTime10(Timestamp sendTime10) {
    this.sendTime10 = sendTime10;
  }
}
