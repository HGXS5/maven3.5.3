//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgScheduleQuality {
  int id;
  String name;
  int hour;
  int min;
  int sec;
  boolean run;

  public CfgScheduleQuality() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getHour() {
    return this.hour;
  }

  public void setHour(int hour) {
    this.hour = hour;
  }

  public int getMin() {
    return this.min;
  }

  public void setMin(int min) {
    this.min = min;
  }

  public int getSec() {
    return this.sec;
  }

  public void setSec(int sec) {
    this.sec = sec;
  }

  public boolean isRun() {
    return this.run;
  }

  public void setRun(boolean run) {
    this.run = run;
  }
}
