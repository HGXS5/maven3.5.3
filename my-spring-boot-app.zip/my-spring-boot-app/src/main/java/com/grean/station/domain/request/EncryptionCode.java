//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class EncryptionCode {
  String enCode;

  public EncryptionCode() {
  }

  public String getEnCode() {
    return this.enCode;
  }

  public void setEnCode(String enCode) {
    this.enCode = enCode;
  }
}
