//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class DevCmd {
  int cmdID;
  String devName;

  public DevCmd() {
  }

  public int getCmdID() {
    return this.cmdID;
  }

  public void setCmdID(int cmdID) {
    this.cmdID = cmdID;
  }

  public String getDevName() {
    return this.devName;
  }

  public void setDevName(String devName) {
    this.devName = devName;
  }
}
