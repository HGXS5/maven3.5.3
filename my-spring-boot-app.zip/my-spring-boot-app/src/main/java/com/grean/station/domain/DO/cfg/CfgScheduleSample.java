//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgScheduleSample {
  int id;
  int hour;
  int min;
  boolean run;

  public CfgScheduleSample() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getHour() {
    return this.hour;
  }

  public void setHour(int hour) {
    this.hour = hour;
  }

  public int getMin() {
    return this.min;
  }

  public void setMin(int min) {
    this.min = min;
  }

  public boolean isRun() {
    return this.run;
  }

  public void setRun(boolean run) {
    this.run = run;
  }
}
