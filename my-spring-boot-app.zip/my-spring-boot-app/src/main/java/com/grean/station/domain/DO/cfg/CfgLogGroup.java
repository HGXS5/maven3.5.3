//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgLogGroup {
  int id;
  int dev_id;
  int log_id;
  String group;

  public CfgLogGroup() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDev_id() {
    return this.dev_id;
  }

  public void setDev_id(int dev_id) {
    this.dev_id = dev_id;
  }

  public int getLog_id() {
    return this.log_id;
  }

  public void setLog_id(int log_id) {
    this.log_id = log_id;
  }

  public String getGroup() {
    return this.group;
  }

  public void setGroup(String group) {
    this.group = group;
  }
}
