//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.utils;

import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

public class SmsUtil {
    public static final String signName = "绿洁科技";
    public static final String templateCode = "SMS_195260066";
    static final String product = "Dysmsapi";
    static final String domain = "dysmsapi.aliyuncs.com";
    static final String accessKeyId = "LTAI4FuncZyZHXYG6CAodS2T";
    static final String accessKeySecret = "6eRFrTDJ6gYiavy0GRIl9ha7nKSzf5";

    public SmsUtil() {
    }

    public static void sendSmsCode(String phone, String code) {
        try {
            IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", "LTAI4FuncZyZHXYG6CAodS2T", "6eRFrTDJ6gYiavy0GRIl9ha7nKSzf5");
            IAcsClient client = new DefaultAcsClient(profile);
            CommonRequest request = new CommonRequest();
            request.setSysMethod(MethodType.POST);
            request.setSysDomain("dysmsapi.aliyuncs.com");
            request.setSysVersion("2017-05-25");
            request.setSysAction("SendSms");
            request.putQueryParameter("RegionId", "cn-hangzhou");
            request.putQueryParameter("PhoneNumbers", phone);
            request.putQueryParameter("SignName", "绿洁科技");
            request.putQueryParameter("TemplateCode", "SMS_195260066");
            request.putQueryParameter("TemplateParam", "{\"code\":\"" + code + "\"}");
            CommonResponse response = client.getCommonResponse(request);
            System.out.println(response.getData());
        } catch (ClientException var6) {
            var6.printStackTrace();
        }

    }

    public static void sendSmsStation(String phone, String station, String code, String info) {
        try {
            IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", "LTAI4FuncZyZHXYG6CAodS2T", "6eRFrTDJ6gYiavy0GRIl9ha7nKSzf5");
            IAcsClient client = new DefaultAcsClient(profile);
            CommonRequest request = new CommonRequest();
            request.setSysMethod(MethodType.POST);
            request.setSysDomain("dysmsapi.aliyuncs.com");
            request.setSysVersion("2017-05-25");
            request.setSysAction("SendSms");
            request.putQueryParameter("RegionId", "cn-hangzhou");
            request.putQueryParameter("PhoneNumbers", phone);
            request.putQueryParameter("SignName", "绿洁科技");
            request.putQueryParameter("TemplateCode", "SMS_205399088");
            request.putQueryParameter("TemplateParam", "{\"station\":\"" + station + "\",\"code\":\"" + code + "\",\"info\":\"" + info + "\"}");
            CommonResponse response = client.getCommonResponse(request);
            System.out.println(response.getData());
        } catch (ClientException var8) {
            var8.printStackTrace();
        }

    }
}
