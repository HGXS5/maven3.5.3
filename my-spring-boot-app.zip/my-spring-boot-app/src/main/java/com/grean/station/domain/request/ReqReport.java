//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class ReqReport {
    Double dataMin;
    Double dataMax;
    Double dataAvg;

    public ReqReport() {
    }

    public Double getDataMin() {
        return this.dataMin;
    }

    public void setDataMin(Double dataMin) {
        this.dataMin = dataMin;
    }

    public Double getDataMax() {
        return this.dataMax;
    }

    public void setDataMax(Double dataMax) {
        this.dataMax = dataMax;
    }

    public Double getDataAvg() {
        return this.dataAvg;
    }

    public void setDataAvg(Double dataAvg) {
        this.dataAvg = dataAvg;
    }
}
