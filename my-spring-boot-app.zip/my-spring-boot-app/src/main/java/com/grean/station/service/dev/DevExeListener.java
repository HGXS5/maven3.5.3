//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.service.dev;

public interface DevExeListener {
  void OnExeEvent(String var1, int var2, int var3);
}
