//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class SetDriftVal {
    int key;
    String factor;
    Double driftZeroMin;
    Double driftZeroMax;
    Double driftSpanMin;
    Double driftSpanMax;
    Double driftStdMin;
    Double driftStdMax;
    Double driftBlnkMin;
    Double driftBlnkMax;
    Double driftParMin;
    Double driftParMax;

    public SetDriftVal() {
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getFactor() {
        return this.factor;
    }

    public void setFactor(String factor) {
        this.factor = factor;
    }

    public Double getDriftZeroMin() {
        return this.driftZeroMin;
    }

    public void setDriftZeroMin(Double driftZeroMin) {
        this.driftZeroMin = driftZeroMin;
    }

    public Double getDriftZeroMax() {
        return this.driftZeroMax;
    }

    public void setDriftZeroMax(Double driftZeroMax) {
        this.driftZeroMax = driftZeroMax;
    }

    public Double getDriftSpanMin() {
        return this.driftSpanMin;
    }

    public void setDriftSpanMin(Double driftSpanMin) {
        this.driftSpanMin = driftSpanMin;
    }

    public Double getDriftSpanMax() {
        return this.driftSpanMax;
    }

    public void setDriftSpanMax(Double driftSpanMax) {
        this.driftSpanMax = driftSpanMax;
    }

    public Double getDriftStdMin() {
        return this.driftStdMin;
    }

    public void setDriftStdMin(Double driftStdMin) {
        this.driftStdMin = driftStdMin;
    }

    public Double getDriftStdMax() {
        return this.driftStdMax;
    }

    public void setDriftStdMax(Double driftStdMax) {
        this.driftStdMax = driftStdMax;
    }

    public Double getDriftBlnkMin() {
        return this.driftBlnkMin;
    }

    public void setDriftBlnkMin(Double driftBlnkMin) {
        this.driftBlnkMin = driftBlnkMin;
    }

    public Double getDriftBlnkMax() {
        return this.driftBlnkMax;
    }

    public void setDriftBlnkMax(Double driftBlnkMax) {
        this.driftBlnkMax = driftBlnkMax;
    }

    public Double getDriftParMin() {
        return this.driftParMin;
    }

    public void setDriftParMin(Double driftParMin) {
        this.driftParMin = driftParMin;
    }

    public Double getDriftParMax() {
        return this.driftParMax;
    }

    public void setDriftParMax(Double driftParMax) {
        this.driftParMax = driftParMax;
    }
}
