//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgUploadCom extends CfgUploadNet {
    public CfgUploadCom() {
    }
}
