//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.comm;

public interface RecvListener {
  void OnRecvEvent(byte[] var1);
}
