//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class QueryData {
    Double data;
    String flag;

    public QueryData() {
    }

    public Double getData() {
        return this.data;
    }

    public void setData(Double data) {
        this.data = data;
    }

    public String getFlag() {
        return this.flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
