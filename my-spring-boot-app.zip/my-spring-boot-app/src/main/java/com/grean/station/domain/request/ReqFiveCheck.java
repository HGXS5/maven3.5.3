//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class ReqFiveCheck {
    String factorName;
    Double stdValue;
    Double testValue;
    String allowError;
    String curError;

    public ReqFiveCheck() {
    }

    public String getFactorName() {
        return this.factorName;
    }

    public void setFactorName(String factorName) {
        this.factorName = factorName;
    }

    public Double getStdValue() {
        return this.stdValue;
    }

    public void setStdValue(Double stdValue) {
        this.stdValue = stdValue;
    }

    public Double getTestValue() {
        return this.testValue;
    }

    public void setTestValue(Double testValue) {
        this.testValue = testValue;
    }

    public String getAllowError() {
        return this.allowError;
    }

    public void setAllowError(String allowError) {
        this.allowError = allowError;
    }

    public String getCurError() {
        return this.curError;
    }

    public void setCurError(String curError) {
        this.curError = curError;
    }
}
