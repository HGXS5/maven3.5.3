//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class ReqQualityCmd {
    String qualityName;
    int qualityCmdIndex;

    public ReqQualityCmd() {
    }

    public String getQualityName() {
        return this.qualityName;
    }

    public void setQualityName(String qualityName) {
        this.qualityName = qualityName;
    }

    public int getQualityCmdIndex() {
        return this.qualityCmdIndex;
    }

    public void setQualityCmdIndex(int qualityCmdIndex) {
        this.qualityCmdIndex = qualityCmdIndex;
    }
}
