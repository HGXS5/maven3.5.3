//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgName {
  int id;
  String type;
  String en_name;
  String ch_name;

  public CfgName() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getEn_name() {
    return this.en_name;
  }

  public void setEn_name(String en_name) {
    this.en_name = en_name;
  }

  public String getCh_name() {
    return this.ch_name;
  }

  public void setCh_name(String ch_name) {
    this.ch_name = ch_name;
  }
}
