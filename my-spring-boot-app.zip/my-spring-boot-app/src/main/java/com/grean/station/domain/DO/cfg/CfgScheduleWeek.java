//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgScheduleWeek {
  int id;
  int day;
  int hour;
  int min;
  String task_name;
  String task_code;

  public CfgScheduleWeek() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDay() {
    return this.day;
  }

  public void setDay(int day) {
    this.day = day;
  }

  public int getHour() {
    return this.hour;
  }

  public void setHour(int hour) {
    this.hour = hour;
  }

  public int getMin() {
    return this.min;
  }

  public void setMin(int min) {
    this.min = min;
  }

  public String getTask_name() {
    return this.task_name;
  }

  public void setTask_name(String task_name) {
    this.task_name = task_name;
  }

  public String getTask_code() {
    return this.task_code;
  }

  public void setTask_code(String task_code) {
    this.task_code = task_code;
  }
}
