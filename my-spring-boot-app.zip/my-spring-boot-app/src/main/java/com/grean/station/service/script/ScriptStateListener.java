//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.service.script;

public interface ScriptStateListener {
  void OnStateEvent(String var1);
}
