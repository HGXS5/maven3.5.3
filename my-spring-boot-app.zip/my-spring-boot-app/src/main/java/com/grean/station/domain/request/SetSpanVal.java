//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class SetSpanVal {
    int key;
    String factor;
    Double spanVal;

    public SetSpanVal() {
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getFactor() {
        return this.factor;
    }

    public void setFactor(String factor) {
        this.factor = factor;
    }

    public Double getSpanVal() {
        return this.spanVal;
    }

    public void setSpanVal(Double spanVal) {
        this.spanVal = spanVal;
    }
}
