//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgDevLog {
  int id;
  int dev_id;
  int log_id;
  String log_type;
  String log_desc;

  public CfgDevLog() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDev_id() {
    return this.dev_id;
  }

  public void setDev_id(int dev_id) {
    this.dev_id = dev_id;
  }

  public int getLog_id() {
    return this.log_id;
  }

  public void setLog_id(int log_id) {
    this.log_id = log_id;
  }

  public String getLog_type() {
    return this.log_type;
  }

  public void setLog_type(String log_type) {
    this.log_type = log_type;
  }

  public String getLog_desc() {
    return this.log_desc;
  }

  public void setLog_desc(String log_desc) {
    this.log_desc = log_desc;
  }
}
