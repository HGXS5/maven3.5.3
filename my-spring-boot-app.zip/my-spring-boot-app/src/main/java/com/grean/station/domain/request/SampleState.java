//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class SampleState {
    int bottleID;
    Integer sampleVolume;
    String sampleUnit;
    String sampleTime;

    public SampleState() {
    }

    public int getBottleID() {
        return this.bottleID;
    }

    public void setBottleID(int bottleID) {
        this.bottleID = bottleID;
    }

    public Integer getSampleVolume() {
        return this.sampleVolume;
    }

    public void setSampleVolume(Integer sampleVolume) {
        this.sampleVolume = sampleVolume;
    }

    public String getSampleUnit() {
        return this.sampleUnit;
    }

    public void setSampleUnit(String sampleUnit) {
        this.sampleUnit = sampleUnit;
    }

    public String getSampleTime() {
        return this.sampleTime;
    }

    public void setSampleTime(String sampleTime) {
        this.sampleTime = sampleTime;
    }
}
