//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgDevCmd {
  int id;
  int devid;
  int factorid;
  int cmdType;
  int cmdIndex;
  String cmdString;
  String protoType;
  int cmdDelay;

  public CfgDevCmd() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDevid() {
    return this.devid;
  }

  public void setDevid(int devid) {
    this.devid = devid;
  }

  public int getFactorid() {
    return this.factorid;
  }

  public void setFactorid(int factorid) {
    this.factorid = factorid;
  }

  public int getCmdType() {
    return this.cmdType;
  }

  public void setCmdType(int cmdType) {
    this.cmdType = cmdType;
  }

  public int getCmdIndex() {
    return this.cmdIndex;
  }

  public void setCmdIndex(int cmdIndex) {
    this.cmdIndex = cmdIndex;
  }

  public String getCmdString() {
    return this.cmdString;
  }

  public void setCmdString(String cmdString) {
    this.cmdString = cmdString;
  }

  public String getProtoType() {
    return this.protoType;
  }

  public void setProtoType(String protoType) {
    this.protoType = protoType;
  }

  public int getCmdDelay() {
    return this.cmdDelay;
  }

  public void setCmdDelay(int cmdDelay) {
    this.cmdDelay = cmdDelay;
  }
}
