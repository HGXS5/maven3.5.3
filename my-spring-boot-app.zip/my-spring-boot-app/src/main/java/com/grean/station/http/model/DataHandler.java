//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.http.model;

import java.util.List;

public interface DataHandler {
  boolean handleDatas(List<ThData> var1);
}
