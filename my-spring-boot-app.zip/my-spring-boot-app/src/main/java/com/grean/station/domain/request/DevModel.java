//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class DevModel {
  String devName;
  String devMode;

  public DevModel() {
  }

  public String getDevName() {
    return this.devName;
  }

  public void setDevName(String devName) {
    this.devName = devName;
  }

  public String getDevMode() {
    return this.devMode;
  }

  public void setDevMode(String devMode) {
    this.devMode = devMode;
  }
}
