//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class DevInterval {
  String devName;
  Integer intervalType;
  Integer intervalVal;

  public DevInterval() {
  }

  public String getDevName() {
    return this.devName;
  }

  public void setDevName(String devName) {
    this.devName = devName;
  }

  public Integer getIntervalType() {
    return this.intervalType;
  }

  public void setIntervalType(Integer intervalType) {
    this.intervalType = intervalType;
  }

  public Integer getIntervalVal() {
    return this.intervalVal;
  }

  public void setIntervalVal(Integer intervalVal) {
    this.intervalVal = intervalVal;
  }
}
