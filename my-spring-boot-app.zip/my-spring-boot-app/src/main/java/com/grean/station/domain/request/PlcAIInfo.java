//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class PlcAIInfo {
  int key;
  private String name;
  private String pname;
  private int address;
  private float low;
  private float high;

  public PlcAIInfo() {
  }

  public int getKey() {
    return this.key;
  }

  public void setKey(int key) {
    this.key = key;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPname() {
    return this.pname;
  }

  public void setPname(String pname) {
    this.pname = pname;
  }

  public int getAddress() {
    return this.address;
  }

  public void setAddress(int address) {
    this.address = address;
  }

  public float getLow() {
    return this.low;
  }

  public void setLow(float low) {
    this.low = low;
  }

  public float getHigh() {
    return this.high;
  }

  public void setHigh(float high) {
    this.high = high;
  }
}
