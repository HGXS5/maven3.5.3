//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgDevParam {
  int id;
  int dev_id;
  String param_name;
  Double range_min;
  Double range_max;
  Double param_min;
  Double param_max;

  public CfgDevParam() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDev_id() {
    return this.dev_id;
  }

  public void setDev_id(int dev_id) {
    this.dev_id = dev_id;
  }

  public String getParam_name() {
    return this.param_name;
  }

  public void setParam_name(String param_name) {
    this.param_name = param_name;
  }

  public Double getRange_min() {
    return this.range_min;
  }

  public void setRange_min(Double range_min) {
    this.range_min = range_min;
  }

  public Double getRange_max() {
    return this.range_max;
  }

  public void setRange_max(Double range_max) {
    this.range_max = range_max;
  }

  public Double getParam_min() {
    return this.param_min;
  }

  public void setParam_min(Double param_min) {
    this.param_min = param_min;
  }

  public Double getParam_max() {
    return this.param_max;
  }

  public void setParam_max(Double param_max) {
    this.param_max = param_max;
  }
}
