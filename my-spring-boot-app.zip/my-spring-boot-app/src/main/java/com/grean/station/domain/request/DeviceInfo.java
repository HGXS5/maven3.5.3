//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class DeviceInfo {
  String devName;

  public DeviceInfo() {
  }

  public String getDevName() {
    return this.devName;
  }

  public void setDevName(String devName) {
    this.devName = devName;
  }
}
