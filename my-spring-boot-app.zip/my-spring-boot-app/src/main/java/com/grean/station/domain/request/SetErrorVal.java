//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class SetErrorVal {
    int key;
    String factor;
    Double errorZeroMin;
    Double errorZeroMax;
    Double errorSpanMin;
    Double errorSpanMax;
    Double errorStdMin;
    Double errorStdMax;
    Double errorBlnkMin;
    Double errorBlnkMax;

    public SetErrorVal() {
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getFactor() {
        return this.factor;
    }

    public void setFactor(String factor) {
        this.factor = factor;
    }

    public Double getErrorZeroMin() {
        return this.errorZeroMin;
    }

    public void setErrorZeroMin(Double errorZeroMin) {
        this.errorZeroMin = errorZeroMin;
    }

    public Double getErrorZeroMax() {
        return this.errorZeroMax;
    }

    public void setErrorZeroMax(Double errorZeroMax) {
        this.errorZeroMax = errorZeroMax;
    }

    public Double getErrorSpanMin() {
        return this.errorSpanMin;
    }

    public void setErrorSpanMin(Double errorSpanMin) {
        this.errorSpanMin = errorSpanMin;
    }

    public Double getErrorSpanMax() {
        return this.errorSpanMax;
    }

    public void setErrorSpanMax(Double errorSpanMax) {
        this.errorSpanMax = errorSpanMax;
    }

    public Double getErrorStdMin() {
        return this.errorStdMin;
    }

    public void setErrorStdMin(Double errorStdMin) {
        this.errorStdMin = errorStdMin;
    }

    public Double getErrorStdMax() {
        return this.errorStdMax;
    }

    public void setErrorStdMax(Double errorStdMax) {
        this.errorStdMax = errorStdMax;
    }

    public Double getErrorBlnkMin() {
        return this.errorBlnkMin;
    }

    public void setErrorBlnkMin(Double errorBlnkMin) {
        this.errorBlnkMin = errorBlnkMin;
    }

    public Double getErrorBlnkMax() {
        return this.errorBlnkMax;
    }

    public void setErrorBlnkMax(Double errorBlnkMax) {
        this.errorBlnkMax = errorBlnkMax;
    }
}
