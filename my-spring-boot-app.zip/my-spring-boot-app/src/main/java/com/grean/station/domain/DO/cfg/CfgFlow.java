//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgFlow {
  int id;
  boolean record;
  int record_circle;
  boolean upload;

  public CfgFlow() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public boolean isRecord() {
    return this.record;
  }

  public void setRecord(boolean record) {
    this.record = record;
  }

  public int getRecord_circle() {
    return this.record_circle;
  }

  public void setRecord_circle(int record_circle) {
    this.record_circle = record_circle;
  }

  public boolean isUpload() {
    return this.upload;
  }

  public void setUpload(boolean upload) {
    this.upload = upload;
  }
}
