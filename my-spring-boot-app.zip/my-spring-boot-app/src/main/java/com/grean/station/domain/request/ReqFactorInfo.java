//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.request;

public class ReqFactorInfo {
    String factorName;
    Double factorValue;
    String factorUnit;
    String factorType;

    public ReqFactorInfo() {
    }

    public String getFactorName() {
        return this.factorName;
    }

    public void setFactorName(String factorName) {
        this.factorName = factorName;
    }

    public Double getFactorValue() {
        return this.factorValue;
    }

    public void setFactorValue(Double factorValue) {
        this.factorValue = factorValue;
    }

    public String getFactorUnit() {
        return this.factorUnit;
    }

    public void setFactorUnit(String factorUnit) {
        this.factorUnit = factorUnit;
    }

    public String getFactorType() {
        return this.factorType;
    }

    public void setFactorType(String factorType) {
        this.factorType = factorType;
    }
}
