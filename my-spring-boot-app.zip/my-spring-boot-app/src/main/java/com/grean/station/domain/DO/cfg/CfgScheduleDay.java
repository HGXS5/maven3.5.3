//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgScheduleDay {
  int id;
  int hour;
  int min;
  String task_name;
  Integer task_code;
  String factor_list;
  String factor_list2;

  public CfgScheduleDay() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getHour() {
    return this.hour;
  }

  public void setHour(int hour) {
    this.hour = hour;
  }

  public int getMin() {
    return this.min;
  }

  public void setMin(int min) {
    this.min = min;
  }

  public String getTask_name() {
    return this.task_name;
  }

  public void setTask_name(String task_name) {
    this.task_name = task_name;
  }

  public Integer getTask_code() {
    return this.task_code;
  }

  public void setTask_code(Integer task_code) {
    this.task_code = task_code;
  }

  public String getFactor_list() {
    return this.factor_list;
  }

  public void setFactor_list(String factor_list) {
    this.factor_list = factor_list;
  }

  public String getFactor_list2() {
    return this.factor_list2;
  }

  public void setFactor_list2(String factor_list2) {
    this.factor_list2 = factor_list2;
  }
}
