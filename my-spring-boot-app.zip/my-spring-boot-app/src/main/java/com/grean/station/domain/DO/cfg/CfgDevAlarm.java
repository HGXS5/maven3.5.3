//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.grean.station.domain.DO.cfg;

public class CfgDevAlarm {
  int id;
  int dev_id;
  int alarm_id;
  String alarm_type;
  String alarm_desc;

  public CfgDevAlarm() {
  }

  public int getId() {
    return this.id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public int getDev_id() {
    return this.dev_id;
  }

  public void setDev_id(int dev_id) {
    this.dev_id = dev_id;
  }

  public int getAlarm_id() {
    return this.alarm_id;
  }

  public void setAlarm_id(int alarm_id) {
    this.alarm_id = alarm_id;
  }

  public String getAlarm_type() {
    return this.alarm_type;
  }

  public void setAlarm_type(String alarm_type) {
    this.alarm_type = alarm_type;
  }

  public String getAlarm_desc() {
    return this.alarm_desc;
  }

  public void setAlarm_desc(String alarm_desc) {
    this.alarm_desc = alarm_desc;
  }
}
