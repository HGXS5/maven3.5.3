INSERT INTO `cfg_name` VALUES ('88', '协议', 'tox.DevToxBbe', 'BBE鱼毒性仪协议');
