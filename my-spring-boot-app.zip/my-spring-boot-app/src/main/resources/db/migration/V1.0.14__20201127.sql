INSERT INTO `cfg_name` VALUES ('83', '协议', 'SmsFourFaith', '四信SMS协议');
