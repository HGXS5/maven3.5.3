
INSERT INTO `cfg_name` VALUES ('81', '协议', 'smx2400', '康耐德2400协议');

