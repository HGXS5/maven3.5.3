ALTER TABLE cfg_schedule_day ADD COLUMN factor_list2 varchar(200) DEFAULT NULL;

