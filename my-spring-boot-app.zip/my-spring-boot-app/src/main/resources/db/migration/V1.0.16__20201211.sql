INSERT INTO `cfg_name` VALUES ('84', '协议', 'tox.DevToxGreanOld', '绿洁毒性仪老协议');
