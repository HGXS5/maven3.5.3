INSERT INTO `cfg_name` VALUES ('82', '协议', 'SampleGrasp2', '格雷斯普留样器2');
