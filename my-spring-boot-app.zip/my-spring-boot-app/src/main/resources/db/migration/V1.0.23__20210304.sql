ALTER TABLE cfg_dev ADD COLUMN reg_name varchar(40) DEFAULT NULL;

