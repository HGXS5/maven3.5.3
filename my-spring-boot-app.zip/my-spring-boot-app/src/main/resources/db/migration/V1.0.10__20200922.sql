#增加Th流量计协议定义

INSERT INTO `cfg_name` VALUES ('80', '协议', 'DevFlowLinkQuest', 'LinkQuest流量计协议');

