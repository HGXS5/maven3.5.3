ALTER TABLE cfg_dev modify COLUMN address bigint(20) NOT NULL DEFAULT 1;
