INSERT INTO `cfg_name` VALUES ('86', '协议', 'SampleHengda', '恒达留样器协议');
