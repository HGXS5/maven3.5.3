#扩展上传平台数量
ALTER TABLE rec_avg_day ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_avg_day ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_avg_day ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_avg_day ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_avg_day ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_avg_day ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_avg_day ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_avg_hour ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_avg_hour ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_avg_hour ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_avg_hour ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_avg_hour ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_avg_hour ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_avg_hour ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_avg_min ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_avg_min ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_avg_min ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_avg_min ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_avg_min ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_avg_min ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_avg_min ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_blank ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_blank ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_blank ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_blank ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_blank ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_blank ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_blank ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_five ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_five ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_five ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_five ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_five ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_five ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_five ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_par ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_par ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_par ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_par ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_par ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_par ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_par ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_rcvr ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_rcvr ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_rcvr ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_rcvr ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_rcvr ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_rcvr ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_rcvr ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_span ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_span ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_span ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_span ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_span ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_span ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_span ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_std ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_std ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_std ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_std ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_std ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_std ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_std ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_check_zero ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_check_zero ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_check_zero ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_check_zero ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_check_zero ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_check_zero ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_check_zero ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_data_five ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_data_five ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_data_five ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_data_five ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_data_five ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_data_five ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_data_five ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_data_hour ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_data_hour ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_data_hour ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_data_hour ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_data_hour ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_data_hour ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_data_hour ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_data_min ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_data_min ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_data_min ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_data_min ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_data_min ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_data_min ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_data_min ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_data_range ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_data_range ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_data_range ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_data_range ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_data_range ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_data_range ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_data_range ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_log_dev ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_log_dev ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_log_dev ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_log_dev ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_log_dev ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_log_dev ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_log_dev ADD COLUMN send_time10 datetime DEFAULT NULL;

ALTER TABLE rec_log_sys ADD COLUMN send_time4 datetime DEFAULT NULL;
ALTER TABLE rec_log_sys ADD COLUMN send_time5 datetime DEFAULT NULL;
ALTER TABLE rec_log_sys ADD COLUMN send_time6 datetime DEFAULT NULL;
ALTER TABLE rec_log_sys ADD COLUMN send_time7 datetime DEFAULT NULL;
ALTER TABLE rec_log_sys ADD COLUMN send_time8 datetime DEFAULT NULL;
ALTER TABLE rec_log_sys ADD COLUMN send_time9 datetime DEFAULT NULL;
ALTER TABLE rec_log_sys ADD COLUMN send_time10 datetime DEFAULT NULL;