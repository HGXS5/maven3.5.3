INSERT INTO `cfg_dev_alarm` VALUES ('26', '0', '200', '仪表告警', '自定义告警');
INSERT INTO `cfg_name` VALUES ('90', '协议', 'cl.DevClBLPowerMon', '布朗卢比氯离子协议');