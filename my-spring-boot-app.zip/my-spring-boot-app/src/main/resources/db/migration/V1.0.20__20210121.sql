INSERT INTO `cfg_name` VALUES ('87', '协议', 'DevFlowLs', '利声流量计协议');
