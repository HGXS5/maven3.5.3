INSERT INTO `cfg_name` VALUES ('85', '协议', 'cod.DevCodYanaco380', 'YanacoCOD协议');
